#ifndef utilities_H_
#define utilities_H_

#define MIN_MODE_SIZE 3
#define MAX_MODE_SIZE 5
#define MICROSECONDS_TO_MILLISECONDS 0.001
#define SECONDS_TO_MILLISECONDS 1000

#endif